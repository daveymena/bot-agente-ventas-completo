# Handoff: Rediseño móvil + escritorio de VentasPro

## Overview
Rediseño visual del dashboard de VentasPro (escritorio y móvil), la tienda pública multi-negocio, el asistente "Atlas" (Arquitecto IA) y el widget de ayuda flotante. Corrige overflow/desbordes de botones, imágenes rotas, y aplica un estilo compacto tipo Android + un tema de tienda configurable por tipo de negocio.

## About the Design Files
Los 3 archivos `.dc.html` de esta carpeta son **referencias de diseño en HTML**, no código para copiar tal cual. Son prototipos de alta fidelidad (colores, tipografía, spacing y layout exactos). La tarea es **recrear este diseño en el stack real** (React + Tailwind/CSS del repo `daveymena/bot-agente-ventas-completo`, artifacts en `artifacts/ventas-pro`), reutilizando sus componentes existentes (`layout.tsx`, `mobile-nav.tsx`, `mobile-dashboard.tsx`, `HelpChatWidget.tsx`, páginas en `src/pages`).

## Fidelity
**Alta fidelidad (hifi).** Todos los valores de color, radio de borde, tipografía y espaciado deben tomarse tal cual aparecen en el HTML (son inline styles — cada elemento trae su valor exacto).

## Files
- `VentasPro.dc.html` — Dashboard de escritorio completo: Panel, Conversaciones, Agentes IA, Prospectos, Productos, WhatsApp, WooCommerce, **Arquitecto IA (Atlas)** rediseñado como chat con burbujas/avatar/chips, Personalización, Facebook (con pestañas: Páginas, Campañas, Formularios de leads, Webhook), Configuración, Ayuda, Monitor WA, Administrador, Planes. Incluye el **widget de ayuda flotante** (burbuja + panel) en la esquina inferior derecha, visible en cualquier pantalla.
- `VentasPro-Movil.dc.html` — Las mismas pantallas centrales en formato teléfono Android (bezel incluido vía `android-frame.jsx`): Panel, Conversaciones, Chat, Productos, Prospectos, Cursos, y el panel "Más" (menú completo tipo bottom-sheet).
- `Tienda.dc.html` — Tienda pública multi-negocio: hero de portada, fila de colecciones destacadas, grid de productos, vista cliente y vista de administración con selector de tema (4 tipos de negocio × 4 plantillas × 5 colores de marca, con vista previa en vivo).

## Screens / Views

### 1. Dashboard — navegación lateral (escritorio)
- Sidebar fijo 264px, fondo `#0f172b`, texto `#b1b9c6`.
- Logo: cuadrado 28px `border-radius:8px` color `#4f46e5` + wordmark "VentasPro" 16px/800.
- Ítem activo: fondo `#4f46e5`, texto blanco, `border-radius:8px`, altura 44px.
- Íconos: lucide-react, 18px.

### 2. Arquitecto IA ("Atlas")
- Layout: `display:flex;flex-wrap:wrap;gap:24px;max-width:1280px`. Panel de chat `flex:2 1 460px;min-width:380px` + sidebar de info `flex:1 1 260px;min-width:240px` (el sidebar baja debajo del chat si no cabe — evita que todo se comprima).
- Header del chat: degradado `linear-gradient(90deg,#312e81,#4f46e5)`, avatar 38px con ícono `sparkles`, punto verde de "en línea" `#4ade80`.
- Burbujas: usuario alineado a la derecha fondo `#4f46e5` texto blanco `border-radius:16px 4px 16px 16px`; asistente a la izquierda fondo blanco borde `#eef1f6` `border-radius:4px 16px 16px 16px`, sombra sutil `0 1px 2px rgba(15,23,42,.04)`.
- Indicador de "escribiendo": 3 puntos con animación `atlas-bounce` (keyframes en el `<helmet>`).
- Chips de acción rápida: fondo `#eef0fe`, texto `#4f46e5`, `border-radius:999px`.
- Sidebar: tarjetas "Capacidades de Atlas" y "Cambios recientes", fondo blanco, borde `#e2e8f0`, `border-radius:16px`.

### 3. Widget de ayuda flotante (global, todas las pantallas)
- Botón lanzador: 60×60px, círculo, degradado `linear-gradient(135deg,#4338ca,#4f46e5)`, sombra `0 14px 32px -8px rgba(79,70,229,.5)`, badge rojo de notificación 16px cuando está cerrado.
- Panel: 368×520px, `border-radius:22px`, sombra `0 30px 70px -14px rgba(15,23,42,.4)`.
- Header con degradado morado, avatar con ícono `sparkles`, subtítulo "En línea · responde al instante".
- Burbujas con timestamp debajo (10.5px, `#9aa3b4`).
- CTA de escalamiento a WhatsApp: pastilla verde `#eafaf0`/`#16a34a` con ícono `phone`.
- Chips de sugerencia sobre el input; input en cápsula `border-radius:999px` fondo `#f6f7fb`.
- Mapea 1:1 a la lógica ya existente en `src/components/HelpChatWidget.tsx` (mismo flujo: preguntas sobre planes/facturación, botón de WhatsApp cuando el bot no resuelve). Solo se está actualizando el estilo visual, no el comportamiento.

### 4. Facebook (escritorio)
- 4 pestañas: Páginas, Campañas, Formularios de leads, Webhook (tabs con `data-fb-tab`/`data-fb-panel`, un solo panel `display:flex|block` visible a la vez — importante: no usar `display:flex` en todos los paneles, solo el que corresponda, o el contenido se desborda).
- Páginas: tarjeta de página de Facebook conectada + tarjeta de Instagram sin conectar con CTA.
- Webhook: URL de callback, token de verificación, botón "Rotar token".

### 5. Tienda pública (multi-negocio)
- Hero: fondo `#0f172b`, imagen de portada con overlay `linear-gradient(90deg,rgba(15,23,43,.92) 0%,rgba(15,23,43,.55) 55%,rgba(15,23,43,.15) 100%)`, H1 44px/800, dos CTAs (uno sólido `#4f46e5`, uno translúcido).
- Fila de 4 colecciones destacadas con foto (aspect-ratio 4/3, overlay degradado inferior para legibilidad del texto).
- Tarjetas de producto: `border-radius:18px`, hover con sombra `0 24px 40px -16px rgba(15,23,42,.2)`.
- **Panel de Apariencia (admin)**: selector de tipo de negocio (Tecnología, Cursos, Moda, Servicios) → cada tipo define una plantilla por defecto (Escaparate/Landing/Editorial/Minimalista). Selector de color de marca (5 swatches) y editor de portada (`<image-slot>`). Vista previa en vivo que refleja plantilla + tipo de negocio + color seleccionados.

## Interactions & Behavior
- Todo el estado de navegación es local (clicks en `<nav>`/sidebar cambian `state.screen`).
- El widget de ayuda y Atlas no llaman a ningún backend real (son mockups) — en producción deben conectarse a los endpoints ya existentes (`/api/public/help-chat` para el widget; el motor de Arquitecto IA real para Atlas).
- Pestañas de Facebook: al hacer clic, ocultar todos los `data-fb-panel` y mostrar solo el seleccionado.
- Selector de tema de tienda: clic en tipo de negocio autoselecciona su plantilla recomendada; clic en plantilla o color individual los sobreescribe.

## Design Tokens
- **Color primario**: `#4f46e5` (indigo), hover/activo `#4338ca`.
- **Fondo sidebar**: `#0f172b`.
- **Bordes**: `#e2e8f0` (escritorio), `#eef1f6` (móvil/tienda).
- **Texto secundario**: `#64748b` / `#94a3b8`.
- **Verde de éxito/WhatsApp**: `#16a34a` / fondo `#eafaf0` o `rgba(34,197,94,.1)`.
- **Rojo de alerta/badge**: `#ef4444`.
- **Tipografía**: system font stack (sin import de Google Fonts) — usar la fuente ya definida en el proyecto real.
- **Radios**: 8-12px (controles/tarjetas de escritorio), 14-22px (burbujas de chat, tarjetas de tienda, paneles flotantes), 999px (píldoras/chips/inputs redondeados).
- **Sombras**: `0 1px 2px rgba(15,23,42,.04)` (burbujas), `0 12-30px ...rgba(79,70,229,.5)` (elementos flotantes con acento de marca).

## Assets
No se usan imágenes reales — todos los placeholders de foto son cajas con `repeating-linear-gradient` rayado + texto Menlo/monospace indicando qué foto va ahí (ej. "foto de producto"). El usuario debe reemplazarlos con fotografía real de catálogo/portada al implementar.

## Known fixes already applied (don't regress)
- Logos rotos (`assets/logo.svg`, `assets/store-logo.svg`) reemplazados por wordmark + bloque de color — el repo real debe usar el logo real, no placeholders.
- Imágenes de producto rotas reemplazadas por placeholders rayados.
- Bug de overflow en pestañas de Facebook: cada panel debe tener su propio `display` (flex o block) al mostrarse, no forzar `flex` en todos.
- Layout de Atlas: el panel de chat necesita `min-width` explícito y el contenedor `flex-wrap:wrap`, si no, en pantallas angostas el chat se comprime y el texto se corta.
